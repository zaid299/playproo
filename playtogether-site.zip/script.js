function joinMatch() {
  alert('Thanks for joining the match! We will notify you with more details.');
}
